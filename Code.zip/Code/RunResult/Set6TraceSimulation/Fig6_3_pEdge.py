from RunResult.Set6TraceSimulation.formalRun import formalRunBar
import Algorithm.SimulationTraceDriven.problemInstance as pI
import Algorithm.utils as utils


#
if __name__ == '__main__':
    trace = 1
    K = 1.3
    V = 100
    barsReward = []
    barsRuntime = []
    barsRewardList = []
    barsRuntimeList = []

    for pEdge in [.1,.2,.3,.4,.5]:  # pEdge in [.1,.2,.3,.4,.5]
        K, V, G, R, D, pD, sigma, supportReward, c = pI.problemInstancePEdgeAdd(K, V, pEdge)
        rewardBar, runtimeBar, rewardConfidentialIntervalList, runtimeConfidentialIntervalList = formalRunBar(K, V, G,
                                                                                                              R, D, pD,
                                                                                                              sigma,
                                                                                                              supportReward,
                                                                                                              c)
        barsReward.append(rewardBar)
        barsRuntime.append(runtimeBar)
        barsRewardList.append(rewardConfidentialIntervalList)
        barsRuntimeList.append(runtimeConfidentialIntervalList)
    print(barsReward, "\n", barsRuntime)
    barsRewardList = utils.calculateConfIntervalForBatch(barsRewardList)
    barsRuntimeList = utils.calculateConfIntervalForBatch(barsRuntimeList)
    print("barsRewardList", barsRewardList)
    print("barsRuntimeList", barsRuntimeList)