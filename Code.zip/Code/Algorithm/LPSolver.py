from pulp import LpMaximize, LpProblem, LpStatus, lpSum, LpVariable, LpBinary, PULP_CBC_CMD

# The LPSolver Function solves the linear programming problem

# G: Graph structure G[u,v]=true if there is an edge
# r: realized reward of each edge
# c: the capacity of each node
def LPSolver(V,G,r,c):
    model = LpProblem(name = "LPRelaxation", sense=LpMaximize)
    X = [[LpVariable(name = "x_"+str(u)+","+str(v), lowBound=0,upBound=1) for v in range(V)] for u in range(V)]
    # we only use (u,v) v>u to index edges
    # print(X)
    print("x_{u,v} initialized")
    # capacity constraint
    for u in range(V):
        # each node u has a capacity constraint
        sum_u = 0
        for v in range(V):
            if not G[u,v] or u==v:
                continue
            firstNode = min(u,v)
            secondNode = max(u,v)
            sum_u+=X[firstNode][secondNode]
        model+=(sum_u<=c[u],"stCapa_"+str(u))
    print("capacity constraint initialized")
    # Objective function
    sum = []
    for u in range(V):
        for v in range(u+1,V):
            if not G[u][v]:
                continue
            sum.append(X[u][v]*r[u][v])
    model+=lpSum((sum))
    print("Objective function initialized")
    # Store optimal fractional solution
    X_optimal = [[0 for v in range(V)] for u in range(V)]
    status = model.solve()
    for u in range(V):
        for v in range(u+1,V):
            if G[u][v]:
                X_optimal[u][v]=X_optimal[v][u]=X[u][v].value()
    return(X_optimal)

# This function solves integer programming of max weight matching
def maxWeightMatching(V,G,r,c):
    model = LpProblem(name="Max_Weight_Matching", sense=LpMaximize)
    X = [[LpVariable(name="x_" + str(u) + "," + str(v), cat=LpBinary) for v in range(V)] for u in range(V)]
    # we only use (u,v) v>u to index edges
    # print(X)
    print("x_{u,v} initialized")
    # capacity constraint
    for u in range(V):
        # each node u has a capacity constraint
        sum_u = 0
        for v in range(V):
            if not G[u, v] or u == v:
                continue
            firstNode = min(u, v)
            secondNode = max(u, v)
            sum_u += X[firstNode][secondNode]
        model += (sum_u <= c[u], "stCapa_" + str(u))
    print("capacity constraint initialized")
    # Objective function
    sum = []
    for u in range(V):
        for v in range(u + 1, V):
            if not G[u][v]:
                continue
            sum.append(X[u][v] * r[u][v])
    model += lpSum((sum))
    print("Objective function initialized")
    # Store optimal fractional solution
    X_optimal = [[0 for v in range(V)] for u in range(V)]
    solver = PULP_CBC_CMD(timeLimit=0.5, msg=False)
    status = model.solve()
    if LpStatus[status] != "Optimal":
        return [[0.0] * V for _ in range(V)]

    for u in range(V):
        for v in range(u + 1, V):
            if G[u][v]:
                X_optimal[u][v] = X_optimal[v][u] = int(X[u][v].value())
    return (X_optimal)
