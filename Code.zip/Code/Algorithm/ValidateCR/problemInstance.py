import numpy as np
import random
import Algorithm.utils as utils

# This file generates problem instance for randomized arriving order, for validating the competitive ratio of the OCKA

# default parameter
# V=20
# maxCapacity = 6
# minCapacity = 3
# pEdge=0.4 # Pr{an edge is set}
# K = 1.3# Ratio between the expected overall edge cost and the knapsack budget
# supportReward = 3

def problemInstance(
    V = 20,
    maxCapacity = 6,
    minCapacity = 3,
    pEdge=0.4,  # Pr{an edge is set}
    K = 5,    # Ratio between the expected overall edge cost and the knapsack budget
    supportReward = 3
):
    # Problem Instance
    c=[random.randint(minCapacity, maxCapacity) for v in range(V)]  # node capacity
    G=np.zeros((V, V), dtype=bool)
    R = [[[] for u in range(V)] for v in range(V)] # matrix for edge reward distribution
    D = [[0 for u in range(V)] for v in range(V)] # matrix for edge cost
    pD = [[-1 for u in range(V)] for v in range(V)] #matrix for edgecost pr
    for u in range(V): #set edges
        for v in range(u+1,V):
            setEdge = np.random.choice([True, False], p=[pEdge, 1 - pEdge])
            if setEdge:
                G[u,v]=setEdge
                G[v,u]=setEdge

                rewardList = sorted(random.uniform(1,5) for i in range(supportReward))
                rewardPrList = [random.random() for i in range(supportReward)]
                normRewardPrList = [x / sum(rewardPrList) for x in rewardPrList]
                R[u][v]=R[v][u]=[rewardList,normRewardPrList]   #matrix for edge reward distribution

                D[u][v]=D[v][u]=random.uniform(1,10)
                pD[u][v]=pD[v][u]=random.random()
                # pD[u][v]=pD[v][u]=1
    expOveCost = 0
    for u in range(V): #set edges
        for v in range(u+1,V):
            if not G[u][v] or u==v:
                continue
            expOveCost+=D[u][v]*pD[u][v]

    for u in range(V): #normalize D
        for v in range(u+1,V):
            D[u][v]=D[v][u]=round((D[u][v]/expOveCost)*K,3)

    D = utils.truncate_list(D)
    print(D)
    print(pD)
    sigma = [i for i in range(V)]
    random.shuffle(sigma)   # arriving order
    # Problem Instance Ready
    return K,V,G,R,D,pD,sigma,supportReward,c