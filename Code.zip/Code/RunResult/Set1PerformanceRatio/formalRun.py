import math

import Algorithm.ValidateCR.problemInstance as pI
import Algorithm.ValidateCR.samplePath as sP
import Algorithm.OfflineOPT as off
from Algorithm.OCKA_numpy import OCKAOffline, OCKAOnline


def formalRunBar(
    V,
    maxCapacity,
    minCapacity,
    pEdge,
    K,
):
    gamma = 1/(3+math.exp(-2))
    cr = gamma/(2*K)
    # one bar one CR
    performance_ratio_list = []
    instances = 15
    realizations = 20
    for instances in range(instances):  # 30 problem instances (5 points)
        K,V,G,R,D,pD,sigma,supportReward,c = pI.problemInstance(V,maxCapacity,minCapacity,pEdge,K)
        offlineOPT = off.OfflineOPT(K,V,G,R,D,pD,sigma,supportReward,c)
        Y_AVG = OCKAOffline(K,V,G,R,D,pD,sigma,supportReward,c, MonteCarloRounds=500)
        E_OCKA = 0
        for paths in range(realizations):
            r,d = sP.samplePath(K,V,G,R,D,pD,sigma,supportReward,c)
            accumulatedReward = OCKAOnline(K,V,G,R,D,pD,sigma,supportReward,c,r,d,Y_AVG)[0]
            E_OCKA+=accumulatedReward
        E_OCKA/=realizations
        performance_ratio_list.append(E_OCKA/offlineOPT)
    return cr,performance_ratio_list