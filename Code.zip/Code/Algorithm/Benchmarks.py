import math
import random
import time

import numpy
import numpy as np
import bisect

import Algorithm.ValidateCR.samplePath as sP
import Algorithm.LPSolver as lp
from Algorithm.LPSolver import maxWeightMatching
import Algorithm.utils as utils

# Benchmark Random
def Random(K,V,G,R,D,pD,sigma,supportReward,c,r,d,):
    arrivedV=[]
    Q=np.zeros((V, V), dtype=bool)    #V*V
    actRemainCapcity = c.copy()
    actRemainKnapsack = 1
    accumulatedReward = 0
    start_time = time.perf_counter()
    for t in range(V):
        print("Random ONLINE ROUND:",t)
        v = sigma[t]    # online arrival of time t
        B=[]    # revealed edges
        for u in arrivedV:
            if not G[u][v]:
                continue
            B.append(u)
        for u in B:
            dice = random.randint(0, 1)
            if dice<1/2 and actRemainCapcity[u]>0 and actRemainCapcity[v]>0 and actRemainKnapsack>d[u][v] and Q[u][v]==False:
                Q[u][v]=Q[v][u]=True
                # print(u,v)
                accumulatedReward+=r[u][v]
                actRemainCapcity[u]-=1
                actRemainCapcity[v]-=1
                actRemainKnapsack-=d[u][v]
        arrivedV.append(v)
    end_time = time.perf_counter()
    runtime = (end_time-start_time)/V
    print(accumulatedReward, runtime)
    return accumulatedReward, runtime

# Benchmark Adaptive
def Adaptive(K,V,G,R,D,pD,sigma,supportReward,c,r,d,):
    arrivedV=[]
    Q=np.zeros((V, V), dtype=bool)    #V*V
    actRemainCapcity = c.copy()
    actRemainKnapsack = 1
    accumulatedReward = 0
    start_time = time.perf_counter()
    for t in range(V):
        print("Adaptive ONLINE ROUND:",t)
        v = sigma[t]    # online arrival of time t
        B=[]    # revealed edges
        for u in arrivedV:
            if not G[u][v]:
                continue
            B.append(u)
        for u in B:
            threshold = (actRemainCapcity[u]/c[u])*(actRemainCapcity[v]/c[v])*(actRemainKnapsack/1)
            dice = random.random()
            if dice<=threshold and actRemainCapcity[u]>0 and actRemainCapcity[v]>0 and actRemainKnapsack>d[u][v] and Q[u][v]==False:
                Q[u][v]=Q[v][u]=True
                accumulatedReward+=r[u][v]
                actRemainCapcity[u]-=1
                actRemainCapcity[v]-=1
                actRemainKnapsack-=d[u][v]
        arrivedV.append(v)
    end_time = time.perf_counter()
    runtime = (end_time-start_time)/V
    print(accumulatedReward, runtime)
    return accumulatedReward, runtime

# Benchmark Karp90
def Greedy(K,V,G,R,D,pD,sigma,supportReward,c,r,d):
    arrivedV=[]
    Q=np.zeros((V, V), dtype=bool)    #V*V
    actRemainCapcity = c.copy()
    actRemainKnapsack = 1
    accumulatedReward = 0
    start_time = time.perf_counter()
    for t in range(V):
        print("Greedy ONLINE ROUND:",t)
        v = sigma[t]    # online arrival of time t
        B=[]    # revealed edges
        for u in arrivedV:
            if not G[u][v]:
                continue
            B.append(u)
        for u in B:
            if actRemainCapcity[u]>0 and actRemainCapcity[v]>0 and actRemainKnapsack>d[u][v] and Q[u][v]==False:
                Q[u][v]=Q[v][u]=True
                accumulatedReward+=r[u][v]
                actRemainCapcity[u]-=1
                actRemainCapcity[v]-=1
                actRemainKnapsack-=d[u][v]
        arrivedV.append(v)
        print("Greedy Remaining Knapsack:", actRemainKnapsack)
    end_time = time.perf_counter()
    runtime = (end_time-start_time)/V
    print(accumulatedReward, runtime)
    return accumulatedReward, runtime

# Benchmark Jiang22
def KnapsackOnly(K,V,G,R,D,pD,sigma,supportReward,c,r,d):

    # set the pr threshold for cleaning distribution
    prThreshold = 1e-5
    # phase 1 variable
    q_c=np.zeros((V, V), dtype=bool)  #V*V
    arrivedV=[]
    # phase 2 variable
    gamma = 1/(3+math.exp(-2))
    X_Dist_Support = numpy.array([0.00])
    X_Dist_PrMass = numpy.array([1.00])
    X_Consumed = 1e-6
    q_k=np.zeros((V, V), dtype=bool)  #V*V
    # final decision
    Q=np.zeros((V, V), dtype=bool)    #V*V
    actRemainCapcity = c.copy()
    actRemainKnapsack = 1
    accumulatedReward = 0
    start_time = time.perf_counter()
    for t in range(V):
        print("KnapsackOnly ONLINE ROUND:", t)
        v=sigma[t]
        B=[]    # revealed edges
        for u in arrivedV:
            if not G[u][v]:
                continue
            B.append(u)

        #phase 2 starts; B is the revealed edges (denoted by the node at the another end)
        q_k_t = []
        for u in B:
            # Find l_1
            theta = max([b_l for b_l in X_Dist_Support if b_l <= 1 - D[u][v]])
            l_1 = np.where(X_Dist_Support == theta)[0][0]
            print("l_1 and theta found:", l_1,theta)
            # Find l_2
            sumPr = 0
            l_2 = l_1 + 1
            while sumPr < gamma:
                l_2 -= 1
                sumPr += X_Dist_PrMass[l_2]
            assert l_2 >= 0
            eta = X_Dist_Support[l_2]
            print("l_2 and eta found:", l_2,eta)
            # Calculate beta
            beta = (gamma - np.sum(X_Dist_PrMass[l_2 + 1:l_1 + 1])) / (K * X_Dist_PrMass[l_2])
            print("sum[eta,theta]:",sumPr)
            print("sum(eta,gamma]:",np.sum(X_Dist_PrMass[l_2 + 1:l_1 + 1]))
            print("beta calculated:", beta)
            beta = min(1,beta)  # rounding error causes beta>1
            beta = max(0,beta)  #rounding error also causes beta<0
            assert 0 <= beta <= 1
            if d[u][v] == 0:
                q_k_t.append(u)
            elif math.isclose(X_Consumed, eta):
                dice = random.random()
                if dice <= beta:
                    q_k_t.append(u)
            elif X_Consumed > eta and X_Consumed <= theta:
                dice = random.random()
                if dice <= 1 / K:
                    q_k_t.append(u)

            print("q^k_t updated for ${v}: ", q_k_t)
            print(X_Consumed,eta,theta)
            print("updated q_k_t in t:",q_k_t)
            # Update reference knapsack consumption
            if u in q_k_t:
                X_Consumed += d[u][v]
                X_Consumed = utils.truncate_one_float(X_Consumed)
            print("reference knapsack consumption updated", X_Consumed)
            # Update reference consumption distribution
            X_Dist_Support_New = X_Dist_Support.copy()
            X_Dist_PrMass_New = X_Dist_PrMass.copy()
            for l in range(l_2 + 1, l_1 + 1):  # (eta, theta]
                # print("updating (eta,theta]")
                b = X_Dist_Support[l]
                movedPr = (pD[u][v] / K) * X_Dist_PrMass[l]
                idx = np.where(X_Dist_Support_New == b)[0][0]
                X_Dist_PrMass_New[idx] -= movedPr
                moved_to = b + D[u][v]
                moved_to = utils.truncate_one_float(moved_to)
                if moved_to in X_Dist_Support_New:
                    idx_to = np.where(X_Dist_Support_New == moved_to)[0][0]
                    X_Dist_PrMass_New[idx_to] += movedPr
                else:
                    idx_insert = bisect.bisect(X_Dist_Support_New, moved_to)
                    X_Dist_Support_New = np.insert(X_Dist_Support_New, idx_insert, moved_to)
                    X_Dist_PrMass_New = np.insert(X_Dist_PrMass_New, idx_insert, movedPr)
            # At eta
            movedPr = pD[u][v] * beta * X_Dist_PrMass[l_2]
            idx_eta = np.where(X_Dist_Support_New == eta)[0][0]
            X_Dist_PrMass_New[idx_eta] = X_Dist_PrMass_New[idx_eta] - movedPr
            moved_to = eta + D[u][v]
            moved_to = utils.truncate_one_float(moved_to)
            if moved_to in X_Dist_Support_New:
                idx_to = np.where(X_Dist_Support_New == moved_to)[0][0]
                X_Dist_PrMass_New[idx_to] += movedPr
            else:
                idx_insert = bisect.bisect(X_Dist_Support_New, moved_to)
                X_Dist_Support_New = np.insert(X_Dist_Support_New, idx_insert, moved_to)
                X_Dist_PrMass_New = np.insert(X_Dist_PrMass_New, idx_insert, movedPr)
            X_Dist_Support = X_Dist_Support_New
            X_Dist_PrMass = X_Dist_PrMass_New
            # clean the support with less than prThreshold pr mass
            mask = X_Dist_PrMass >= prThreshold
            X_Dist_Support = X_Dist_Support[mask]
            X_Dist_PrMass = X_Dist_PrMass[mask]
            X_Dist_PrMass /= X_Dist_PrMass.sum()
            print("reference consumption distribution updated, new length:", len(X_Dist_Support))
        # knapsack part done
        for u in q_k_t:
            q_k[u][v]=q_k[v][u]=True
        # final decision and update remaining capacity and knapsack
        for u in q_k_t:
            if actRemainKnapsack>d[u][v] and actRemainCapcity[u]>0 and actRemainCapcity[v]>0:
                Q[u,v]=Q[v][u]=True
                actRemainCapcity[u]-=1
                assert actRemainCapcity[u]>=0
                actRemainCapcity[v]-=1
                assert actRemainCapcity[v]>=0
                actRemainKnapsack-=d[u][v]
                assert actRemainKnapsack>=0
                accumulatedReward+=r[u][v]
        arrivedV.append(v)
        #done
    end_time = time.perf_counter()
    print(Q)
    runtime = (end_time-start_time)/V
    print(accumulatedReward, runtime)
    return accumulatedReward, runtime

# Benchmark Ezra20 adapted for Simulation
def SingleOCKA(K,V,G,R,D,pD,sigma,supportReward,c,r,d,Y_Average):
    # phase 1 variable
    q_c=np.zeros((V, V), dtype=bool)  #V*V
    arrivedV=[]
    # final decision
    Q=np.zeros((V, V), dtype=bool)    #V*V
    actRemainCapcity = c.copy()
    actRemainKnapsack = 1
    accumulatedReward = 0
    start_time = time.perf_counter()
    for t in range(V):
        print("Single OCKA ONLINE ROUND:",t)
        v = sigma[t]    # online arrival of time t
        q_c_t=[]
        rSample,dSample = sP.samplePath(K,V,G,R,D,pD,sigma,supportReward,c) #dSample will not be used
        B=[]    # revealed edges
        for o in range(c[v]):
            for u in arrivedV:
                if not G[u][v]:
                    continue
                rSample[u][v]=rSample[v][u]=r[u][v]
                B.append(u)
            V_copy = V+1
            G_copy = (G.copy()).tolist()
            G_copy.append([])
            d_copy = d.copy()
            d_copy.append([])
            rSample_copy = rSample.copy()
            rSample_copy.append([])
            for u in range(V):
                G_copy[u].append(G[u][v])
                d_copy[u].append(d[u][v])
                rSample_copy[u].append(rSample[u][v])
            for u in range(V_copy):
                G_copy[-1].append(G_copy[v][u])
                d_copy[-1].append(d_copy[v][u])
                rSample_copy[-1].append(rSample_copy[v][u])
            G_copy=numpy.array(G_copy)
            c_copy = c.copy()
            c_copy[v]=c[v]-1
            c_copy.append(1)


            Y_OPT = maxWeightMatching(V_copy, G_copy, rSample, c_copy)
            edge = -1
            for u in B:
                if Y_OPT[u][V_copy-1]>0:
                    edge = u
                    break

            if edge>-1 and not Q[v][edge]:
                sumPr = 0
                for w in range(V):
                    if G[edge][w] and w in arrivedV:
                        sumPr+=Y_Average[edge][w]
                # calculate phi
                if sumPr==2:
                    phi_u=1
                else:
                    phi_u = 1/(2-sumPr)
                # sample q^c_t
                phi_u = max(0,phi_u)
                phi_u = min(1,phi_u)
                if phi_u==0:
                    continue
                dice_u = random.random()
                if dice_u<=phi_u:
                    if actRemainKnapsack>d[u][v] and actRemainCapcity[u]>0 and actRemainCapcity[v]>0 and Q[u,v]==False:
                        Q[u,v]=Q[v][u]=True
                        actRemainCapcity[u]-=1
                        actRemainCapcity[v]-=1
                        actRemainKnapsack-=d[u][v]
                        accumulatedReward+=r[u][v]
                        q_c_t.append(edge)
        arrivedV.append(v)
    end_time = time.perf_counter()
    runtime = (end_time-start_time)/V
    print(accumulatedReward, runtime)
    return accumulatedReward, runtime

# Benchmark Ezra20 adapted for Trace
def SingleOCKATrace(K,V,G,R,D,pD,sigma,supportReward,c,r,d,Y_Average):
    # phase 1 variable
    q_c=np.zeros((V, V), dtype=bool)  #V*V
    arrivedV=[]
    # final decision
    Q=np.zeros((V, V), dtype=bool)    #V*V
    actRemainCapcity = c.copy()
    actRemainKnapsack = 1
    accumulatedReward = 0
    start_time = time.perf_counter()
    for t in range(V):
        print("ONLINE ROUND:",t)
        v = sigma[t]    # online arrival of time t
        q_c_t=[]
        rSample,dSample = sP.samplePath(K,V,G,R,D,pD,sigma,supportReward,c) #dSample will not be used
        B=[]    # revealed edges
        for o in range(c[v]):
            for u in arrivedV:
                if not G[u][v]:
                    continue
                rSample[u][v]=rSample[v][u]=r[u][v]
                B.append(u)
            V_copy = V+1
            G_copy = (G.copy()).tolist()
            G_copy.append([])
            d_copy = d.copy()
            d_copy.append([])
            rSample_copy = rSample.copy()
            rSample_copy.append([])
            for u in range(V):
                G_copy[u].append(G[u][v])
                d_copy[u].append(d[u][v])
                rSample_copy[u].append(rSample[u][v])
            for u in range(V_copy):
                G_copy[-1].append(G_copy[v][u])
                d_copy[-1].append(d_copy[v][u])
                rSample_copy[-1].append(rSample_copy[v][u])
            G_copy=numpy.array(G_copy)
            c_copy = c.copy()
            c_copy[v]=c[v]-1
            c_copy.append(1)


            Y_OPT = lp.maxWeightMatching(V_copy,G_copy,rSample,c_copy)
            edge = -1
            for u in B:
                # print(Y_OPT)
                if Y_OPT[u][V_copy-1]>0:
                    edge = u
                    break

            if edge>-1 and not Q[v][edge]:
                sumPr = 0
                for w in range(V):
                    if G[edge][w] and w in arrivedV:
                        sumPr+=Y_Average[edge][w]
                # calculate phi
                print("sumPr:", sumPr)
                if sumPr>=2:
                    sumPr/=c[edge]
                if sumPr>=2:
                    phi_u=1
                else:
                    phi_u = 1/(2-sumPr)
                # sample q^c_t
                phi_u = max(0,phi_u)
                phi_u = min(1,phi_u)
                if phi_u==0:
                    continue
                dice_u = random.random()
                if dice_u<=phi_u:
                    if actRemainKnapsack>d[u][v] and actRemainCapcity[u]>0 and actRemainCapcity[v]>0 and Q[u,v]==False:
                        Q[u,v]=Q[v][u]=True
                        actRemainCapcity[u]-=1
                        actRemainCapcity[v]-=1
                        actRemainKnapsack-=d[u][v]
                        accumulatedReward+=r[u][v]
                        q_c_t.append(edge)
        arrivedV.append(v)
    end_time = time.perf_counter()
    runtime = (end_time-start_time)/V
    print(accumulatedReward, runtime)
    return accumulatedReward, runtime

# Ezra2024
def SecretaryGeneralMatching(K,V,G,R,D,pD,sigma,supportReward,c,r,d,Y_Average):
    # initialize k=floor(V/2)
    k = math.floor(V/2)
    arrivedV = []
    V_available = sigma.copy()
    # final decision
    Q = np.zeros((V, V), dtype=bool)  # V*V
    actRemainCapcity = c.copy()
    actRemainKnapsack = 1
    accumulatedReward = 0
    start_time = time.perf_counter()
    for t in range(V):
        print("Secretary ONLINE ROUND:", t)
        v = sigma[t]
        arrivedV.append(v)
        if t<=k:
            continue
        V_prime = arrivedV.copy()
        if t%2==1:
            del V_prime[random.randrange(len(V_prime)-1)]
        G_prime = [[G[i][j] for j in V_prime] for i in V_prime]
        r_prime = [[r[i][j] for j in V_prime] for i in V_prime]
        c_prime = [c[i] for i in V_prime]
        # max weight matching
        X_optimal = lp.maxWeightMatching(len(V_prime),np.array(G_prime),r_prime,c_prime)
        for u_idx in range(len(X_optimal[-1])):
            u = V_prime[u_idx]
            if X_optimal[-1][u_idx]==1 and u in V_available:
                if (actRemainKnapsack>d[u][v] and
                        actRemainCapcity[u]>0 and
                        actRemainCapcity[v]>0 and
                        Q[u,v]==False):
                    Q[u, v] = Q[v][u] = True
                    actRemainCapcity[u] -= 1
                    actRemainCapcity[v] -= 1
                    actRemainKnapsack -= d[u][v]
                    accumulatedReward += r[u][v]
                    V_available.remove(u)
                    V_available.remove(v)
                    break
    end_time = time.perf_counter()
    runtime = (end_time - start_time) / V
    print(accumulatedReward, runtime)
    return accumulatedReward, runtime

# Benchmark Goyal22
def SecretaryCompleteMatching(K,V,G,R,D,pD,sigma,supportReward,c,r,d,Y_Average):
    # initialize k=floor(6V/17)
    k = math.floor(6*V / 17)
    v_prime = []
    A = []
    # final decision
    Q = np.zeros((V, V), dtype=bool)  # V*V
    actRemainCapcity = c.copy()
    actRemainKnapsack = 1
    accumulatedReward = 0
    start_time = time.perf_counter()
    for t in range(k):
        print("Secretary Complete ONLINE ROUND:", t)
        v_prime.append(sigma[t])
        A.append(sigma[t])
    for t in range(k,V):
        print("Secretary Complete ONLINE ROUND:", t)
        v = sigma[t]
        v_prime.append(v)
        if t % 2 == 1:
            del v_prime[random.randrange(len(v_prime) - 1)]
        G_prime = [[G[i][j] for j in v_prime] for i in v_prime]
        r_prime = [[r[i][j] for j in v_prime] for i in v_prime]
        c_prime = [c[i] for i in v_prime]
        # max weight matching
        X_optimal = lp.maxWeightMatching(len(v_prime), np.array(G_prime), r_prime, c_prime)
        v_is_matched = False
        for u_idx in range(len(X_optimal[-1])):
            u = v_prime[u_idx]
            if X_optimal[-1][u_idx] == 1 and u in A:
                if (actRemainKnapsack > d[u][v] and
                    actRemainCapcity[u] > 0 and
                    actRemainCapcity[v] > 0 and
                    Q[u, v] == False):
                    Q[u, v] = Q[v][u] = True
                    actRemainCapcity[u] -= 1
                    actRemainCapcity[v] -= 1
                    actRemainKnapsack -= d[u][v]
                    accumulatedReward += r[u][v]
                    A.remove(u)
                    v_is_matched = True
                    break
        if not v_is_matched:
            if len(A)<(V+1-t):
                A.append(v)
            else:
                u = A[random.randrange(len(A))]
                if (actRemainKnapsack > d[u][v] and
                    actRemainCapcity[u] > 0 and
                    actRemainCapcity[v] > 0 and
                    Q[u, v] == False):
                    Q[u, v] = Q[v][u] = True
                    actRemainCapcity[u] -= 1
                    actRemainCapcity[v] -= 1
                    actRemainKnapsack -= d[u][v]
                    accumulatedReward += r[u][v]
                    A.remove(u)
                    v_is_matched = True

    end_time = time.perf_counter()
    runtime = (end_time - start_time) / V
    print(accumulatedReward, runtime)
    return accumulatedReward, runtime