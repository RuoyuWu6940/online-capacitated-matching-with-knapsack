import formalRun
if __name__ == '__main__':
    V = 20
    pEdge=0.5  # Pr{an edge is set}
    K = 1.5    # Ratio between the expected overall edge cost and the knapsack budget
    supportReward = 3

    bars = []
    # [3,4,5,6,7]
    for midC in [3,4,5,6,7]:
        maxCapacity = midC+2
        minCapacity = midC-2
        bars.append(formalRun.formalRunBar(V,maxCapacity,minCapacity,pEdge,K))
    print(bars)