from RunResult.Set7TraceSimMatchingOnly.formalRun import formalRunBar
import Algorithm.SimulationTraceDriven.problemInstance as pI
import Algorithm.utils as utils



#
if __name__ == '__main__':
    trace = 1
    K = 1
    barsReward = []
    barsRuntime = []
    barsRewardList = []
    barsRuntimeList = []

    for V in [60,70,80,90,100]:  # V \in [60,70,80,90,100]
        K, V, G, R, D, pD, sigma, supportReward, c = pI.problemInstanceV(K, V)
        rewardBar, runtimeBar, rewardConfidentialIntervalList, runtimeConfidentialIntervalList = formalRunBar(K, V, G, R, D, pD, sigma, supportReward, c)
        barsReward.append(rewardBar)
        barsRuntime.append(runtimeBar)
        barsRewardList.append(rewardConfidentialIntervalList)
        barsRuntimeList.append(runtimeConfidentialIntervalList)
    print(barsReward, "\n", barsRuntime)
    barsRewardList = utils.calculateConfIntervalForBatch(barsRewardList)
    barsRuntimeList = utils.calculateConfIntervalForBatch(barsRuntimeList)
    print("barsRewardList", barsRewardList)
    print("barsRuntimeList", barsRuntimeList)