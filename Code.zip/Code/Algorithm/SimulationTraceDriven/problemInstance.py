import math

import random
import numpy as np
import Algorithm.utils as utils
from Algorithm.TraceDriven import traces

# This file generates problem instances for the simulation experiments based on data features extracted from Trace 4


def traceFeature():
	G, d, c, R, sigma, r = traces.readTrace(100)
	# clean np.float type
	V = len(G)
	return V,G,sigma,c, d

# generate PI for Set6-1 (different V)
def problemInstanceV(K,V_minus):
		supportReward = 3
		V,G,sigma,c, D = traceFeature()
		# Step 1: random remove vertices
		vRemove = 100-V_minus
		for i in range(vRemove):
			del sigma[random.randrange(len(sigma))]
		# Step 2: The arriving order of V in sigma is the new index of V
		# Rebuild V, G, D, pD, and sigma, and c
		V = V_minus
		G_minus=np.zeros((V, V), dtype=bool)
		D_minus = [[0 for u in range(V)] for v in range(V)]  # matrix for edge cost
		pD_minus = [[-1 for u in range(V)] for v in range(V)]  # matrix for edgecost pr
		c_minus = []
		for i in range(V):
			u = sigma[i]
			c_minus.append(c[u])
			for j in range(i+1,V):
				v = sigma[j]
				if G[u,v]==False:
					continue
				G_minus[i,j] = G_minus[j,i] = G[u,v]
				D_minus[i][j] = D_minus[j][i] = D[u][v]
				pD_minus[i][j]=pD_minus[j][i]=1
		D_minus = normalizeCost(D_minus,K)
		sigma = [i for i in range(V)]
		R_minus = prepareRewardDist(V_minus,G_minus,supportReward, sigma)
		return K, V_minus, G_minus, R_minus, D_minus, pD_minus, sigma, supportReward, c_minus

# generate PI for Set6-2 (different Cv)
def problemInstanceCv(K, V_minus, maxCapacity, minCapacity):
	supportReward = 3
	V, G, sigma, c, D = traceFeature()
	G_minus = G
	# Step 1: random generate capacity
	c = [random.randint(minCapacity, maxCapacity) for v in range(V)]  # node capacity
	c_minus = c
	# Step 2: Rebuild pD, R, and D
	pD_minus = [[-1 for u in range(V)] for v in range(V)]  # matrix for edgecost pr
	for i in range(V):
		u = sigma[i]
		for j in range(i + 1, V):
			v = sigma[j]
			if G[u, v] == False:
				continue
			pD_minus[i][j] = pD_minus[j][i] = 1

	D_minus = normalizeCost(D, K)
	R_minus = prepareRewardDist(V_minus, G_minus, supportReward, sigma)
	return K, V_minus, G_minus, R_minus, D_minus, pD_minus, sigma, supportReward, c_minus

# generate PI for Set6-3 (different pEdge for reduce)
def problemInstancePEdge(K,V_minus, pEdge):
		supportReward = 3
		V,G,sigma,c, D = traceFeature()
		# Step 1: random remove vertices
		# Step 2: The arriving order of V in sigma is the new index of V
		# Rebuild V, G, D, pD, and sigma, and c
		V = V_minus
		c_minus = c
		G_minus=np.zeros((V, V), dtype=bool)
		D_minus = [[0 for u in range(V)] for v in range(V)]  # matrix for edge cost
		pD_minus = [[-1 for u in range(V)] for v in range(V)]  # matrix for edgecost pr

		for i in range(V):
			u = sigma[i]
			for j in range(i+1,V):
				v = sigma[j]
				if G[u,v]==False:
					continue
				dice = random.random()
				if dice < pEdge:
					G_minus[i,j] = G_minus[j,i] = G[u,v]
					D_minus[i][j] = D_minus[j][i] = D[u][v]
					pD_minus[i][j]=pD_minus[j][i]=1
		D_minus = normalizeCost(D_minus,K)
		sigma = [i for i in range(V)]
		R_minus = prepareRewardDist(V_minus,G_minus,supportReward, sigma)
		return K, V_minus, G_minus, R_minus, D_minus, pD_minus, sigma, supportReward, c_minus

# generate PI for Set6-3 (different pEdge for add)
def problemInstancePEdgeAdd(K,V_minus, pEdge):
		supportReward = 3
		V,G,sigma,c, D = traceFeature()
		# Step 1: random remove vertices
		# Step 2: The arriving order of V in sigma is the new index of V
		# Rebuild V, G, D, pD, and sigma, and c
		V = V_minus
		c_minus = c
		dMax, dMin = np.array(D).max(), np.array(D).min()
		G_minus=G.copy()
		D_minus = D.copy()  # matrix for edge cost
		pD_minus = [[-1 for u in range(V)] for v in range(V)]  # matrix for edgecost pr

		for i in range(V):
			u = sigma[i]
			for j in range(i+1,V):
				v = sigma[j]
				if not G_minus[u,v]:
					dice = random.random()
					if dice < pEdge:
						G_minus[i,j] = G_minus[j,i] = True
						D_minus[i][j] = D_minus[j][i] = random.uniform(dMax,dMin)
						pD_minus[i][j] = pD_minus[j][i] = 1
				else:
					pD_minus[i][j] = pD_minus[j][i] = 1
		D_minus = normalizeCost(D_minus,K)
		sigma = [i for i in range(V)]
		R_minus = prepareRewardDist(V_minus,G_minus,supportReward, sigma)
		return K, V_minus, G_minus, R_minus, D_minus, pD_minus, sigma, supportReward, c_minus

# generate PI for Set6-4 (different K(beta))
def problemInstanceK(K,V_minus):
		supportReward = 3
		V,G,sigma,c, D = traceFeature()

		V = V_minus
		G_minus=G
		D_minus = D  # matrix for edge cost
		pD_minus = [[-1 for u in range(V)] for v in range(V)]  # matrix for edgecost pr
		c_minus = c
		for i in range(V):
			u = sigma[i]
			for j in range(i+1,V):
				v = sigma[j]
				if G[u,v]==False:
					continue
				pD_minus[i][j]=pD_minus[j][i]=1
		D_minus = normalizeCost(D_minus,K)
		sigma = [i for i in range(V)]
		R_minus = prepareRewardDist(V_minus,G_minus,supportReward, sigma)
		return K, V_minus, G_minus, R_minus, D_minus, pD_minus, sigma, supportReward, c_minus


def normalizeCost(d,K):
	knapsack_factor = (np.sum(np.array(d)) / 2) / K
	d = (np.array(d) / knapsack_factor).tolist()
	d = utils.truncate_list(d)
	return d

def prepareRewardDist(V,G,supportReward,sigma):
	R = [[[] for u in range(V)] for v in range(V)]  # matrix for edge reward distribution
	for u in range(V):  # set edges
		for v in range(u + 1, V):
			if G[u,v]:
				# find t(u)
				t_u = sigma.index(u)
				# find t(v)
				t_v = sigma.index(v)
				# find t(e)
				rewardFactor = math.pow(math.e, ((abs(t_v - t_u)) - V)/12.5)

				rewardList = sorted(random.uniform(1, 5) for i in range(supportReward))
				# scale reward
				rewardList = [(x * rewardFactor + 0) for x in rewardList]
				rewardPrList = [random.random() for i in range(supportReward)]
				normRewardPrList = [x / sum(rewardPrList) for x in rewardPrList]
				R[u][v] = R[v][u] = [rewardList, normRewardPrList]  # matrix for edge reward distribution
	return R

if __name__ == '__main__':
	problemInstanceV(1.5, 70)