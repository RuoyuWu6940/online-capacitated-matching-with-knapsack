import formalRun
if __name__ == '__main__':
    V = 20
    maxCapacity = 7
    minCapacity = 3
    pEdge=0.5  # Pr{an edge is set}
    supportReward = 3

    bars = []
    for K in [1.0,1.25,1.5,1.75,2]:
        bars.append(formalRun.formalRunBar(V,maxCapacity,minCapacity,pEdge,K))
    print(bars)