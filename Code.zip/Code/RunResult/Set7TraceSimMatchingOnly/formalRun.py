import math

import Algorithm.SimulationTraceDriven.samplePath as sP
from Algorithm.matchingOnlyOCKA import OCKAOffline, OCKAOnline
import Algorithm.Benchmarks as bmk


def formalRunBar(K, V, G, R, D, pD, sigma, supportReward, c):

    factor = 2.5
    Instances = 15   #15
    Paths = 20   #20
    algAverageRuns = 20

    OCKA_AVG = 0
    Random_AVG = 0
    Greedy_AVG = 0
    Adaptive_AVG = 0
    Matching_AVG = 0
    Knapsack_AVG = 0
    Secretary_AVG = 0
    SecretaryComplete_AVG = 0
    OCKA_AVG_Runtime = 0
    Random_AVG_Runtime = 0
    Greedy_AVG_Runtime = 0
    Adaptive_AVG_Runtime = 0
    Matching_AVG_Runtime = 0
    Knapsack_AVG_Runtime = 0
    Secretary_AVG_Runtime = 0
    SecretaryComplete_AVG_Runtime = 0

    E_OCKA_List = []
    E_Random_List = []
    E_Greedy_List = []
    E_Adaptive_List = []
    E_Matching_List = []
    E_Secretary_List = []
    E_SecretaryComplete_List = []

    E_OCKA_Runtime_List = []
    E_Random_Runtime_List = []
    E_Greedy_Runtime_List = []
    E_Adaptive_Runtime_List = []
    E_Matching_Runtime_List = []
    E_Secretary_Runtime_List = []
    E_SecretaryComplete_Runtime_List = []
    for instances in range(Instances):

        Y_AVG = OCKAOffline(K,V,G,R,D,pD,sigma,supportReward,c, MonteCarloRounds=500)
        E_OCKA = 0
        E_Random = 0
        E_Greedy = 0
        E_Adaptive = 0
        E_Matching = 0
        E_Knapsack = 0
        E_Secretary = 0
        E_SecretaryComplete = 0
        E_OCKA_Runtime = 0
        E_Random_Runtime = 0
        E_Greedy_Runtime = 0
        E_Adaptive_Runtime = 0
        E_Matching_Runtime = 0
        E_Knapsack_Runtime = 0
        E_Secretary_Runtime = 0
        E_SecretaryComplete_Runtime = 0
        for paths in range(Paths):
            r,d = sP.samplePath(K,V,G,R,D,pD,sigma,supportReward,c)

            for algRun in range(algAverageRuns):

                OCKA_accumulatedReward, OCKA_runtime = OCKAOnline(K,V,G,R,D,pD,sigma,supportReward,c,r,d,Y_AVG)
                Random_accumulatedReward, Random_runtime = bmk.Random(K,V,G,R,D,pD,sigma,supportReward,c,r,d)
                Adaptive_accumulatedReward, Adaptive_runtime = bmk.Adaptive(K,V,G,R,D,pD,sigma,supportReward,c,r,d)
                Matching_accumulatedReward, Matching_runtime = bmk.SingleOCKA(K,V,G,R,D,pD,sigma,supportReward,c,r,d,Y_AVG)
                Secretary_accumulatedReward, Secretary_runtime = bmk.SecretaryGeneralMatching(K, V, G, R, D, pD, sigma, supportReward, c, r, d, Y_AVG)
                SecretaryComplete_accumulatedReward, SecretaryComplete_runtime = bmk.SecretaryCompleteMatching(K, V, G, R, D, pD, sigma, supportReward, c, r, d, Y_AVG)

                E_OCKA+=factor*OCKA_accumulatedReward
                E_Random+=factor*Random_accumulatedReward
                E_Adaptive+=factor*Adaptive_accumulatedReward
                E_Matching+=factor*Matching_accumulatedReward
                E_Secretary += factor*Secretary_accumulatedReward
                E_SecretaryComplete += factor*SecretaryComplete_accumulatedReward

                E_OCKA_Runtime += OCKA_runtime
                E_Random_Runtime += Random_runtime
                E_Adaptive_Runtime += Adaptive_runtime
                E_Matching_Runtime += Matching_runtime
                E_Secretary_Runtime += Secretary_runtime
                E_SecretaryComplete_Runtime += SecretaryComplete_runtime

                E_OCKA_List.append(OCKA_accumulatedReward)
                E_Random_List.append(Random_accumulatedReward)
                E_Adaptive_List.append(Adaptive_accumulatedReward)
                E_Matching_List.append(Matching_accumulatedReward)
                E_Secretary_List.append(Secretary_accumulatedReward)
                E_SecretaryComplete_List.append(SecretaryComplete_accumulatedReward)

                E_OCKA_Runtime_List.append(OCKA_runtime)
                E_Random_Runtime_List.append(Random_runtime)
                E_Adaptive_Runtime_List.append(Adaptive_runtime)
                E_Matching_Runtime_List.append(Matching_runtime)
                E_Secretary_Runtime_List.append(Secretary_runtime)
                E_SecretaryComplete_Runtime_List.append(SecretaryComplete_runtime)

            Greedy_accumulatedReward, Greedy_runtime = bmk.Greedy(K, V, G, R, D, pD, sigma, supportReward, c, r, d)
            E_Greedy += factor * Greedy_accumulatedReward
            E_Greedy_Runtime += Greedy_runtime
            E_Greedy_List.append(Greedy_accumulatedReward)
            E_Greedy_Runtime_List.append(Greedy_runtime)

        E_OCKA/=(Paths*algAverageRuns)
        E_Random/=(Paths*algAverageRuns)
        E_Adaptive/=(Paths*algAverageRuns)
        E_Greedy/=Paths
        E_Matching/=(Paths*algAverageRuns)
        E_Knapsack/=(Paths*algAverageRuns)
        E_Secretary /= (Paths*algAverageRuns)
        E_SecretaryComplete /= (Paths*algAverageRuns)

        E_OCKA_Runtime /= (Paths*algAverageRuns)
        E_Random_Runtime /= (Paths*algAverageRuns)
        E_Adaptive_Runtime /= (Paths*algAverageRuns)
        E_Greedy_Runtime /= Paths
        E_Matching_Runtime /= (Paths*algAverageRuns)
        E_Knapsack_Runtime /= (Paths*algAverageRuns)
        E_Secretary_Runtime /= (Paths*algAverageRuns)
        E_SecretaryComplete_Runtime /= (Paths*algAverageRuns)

        OCKA_AVG+=E_OCKA
        Random_AVG+=E_Random
        Greedy_AVG+=E_Greedy
        Adaptive_AVG+=E_Adaptive
        Matching_AVG+=E_Matching
        Knapsack_AVG+=E_Knapsack
        Secretary_AVG+=E_Secretary
        SecretaryComplete_AVG+= E_SecretaryComplete

        OCKA_AVG_Runtime += E_OCKA_Runtime
        Random_AVG_Runtime += E_Random_Runtime
        Greedy_AVG_Runtime += E_Greedy_Runtime
        Adaptive_AVG_Runtime += E_Adaptive_Runtime
        Matching_AVG_Runtime += E_Matching_Runtime
        Knapsack_AVG_Runtime += E_Knapsack_Runtime
        Secretary_AVG_Runtime += E_Secretary_Runtime
        SecretaryComplete_AVG_Runtime += E_SecretaryComplete_Runtime
    OCKA_AVG/=Instances
    Random_AVG/=Instances
    Greedy_AVG/=Instances
    Adaptive_AVG/=Instances
    Matching_AVG/=Instances
    Knapsack_AVG/=Instances
    Secretary_AVG/=Instances
    SecretaryComplete_AVG/=Instances

    OCKA_AVG_Runtime /= Instances
    Random_AVG_Runtime /= Instances
    Greedy_AVG_Runtime /= Instances
    Adaptive_AVG_Runtime /= Instances
    Matching_AVG_Runtime /= Instances
    Knapsack_AVG_Runtime /= Instances
    Secretary_AVG_Runtime /= Instances
    SecretaryComplete_AVG_Runtime /= Instances
    avgList = [OCKA_AVG,Random_AVG,Greedy_AVG,Adaptive_AVG,Matching_AVG,Secretary_AVG,SecretaryComplete_AVG]
    runTimeList = [OCKA_AVG_Runtime,Random_AVG_Runtime,Greedy_AVG_Runtime,Adaptive_AVG_Runtime,Matching_AVG_Runtime,
                   Secretary_AVG_Runtime,SecretaryComplete_AVG_Runtime]
    avgConfidentialIntervalList = [E_OCKA_List, E_Random_List, E_Greedy_List, E_Adaptive_List,
                                   E_Matching_List, E_Secretary_List, E_SecretaryComplete_List]
    runtimeConfidentialIntervalList = [E_OCKA_Runtime_List, E_Random_Runtime_List, E_Greedy_Runtime_List,
                                       E_Adaptive_Runtime_List, E_Matching_Runtime_List,
                                       E_Secretary_Runtime_List, E_SecretaryComplete_Runtime_List]

    return avgList, runTimeList, avgConfidentialIntervalList, runtimeConfidentialIntervalList