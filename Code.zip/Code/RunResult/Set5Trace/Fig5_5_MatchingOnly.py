from RunResult.Set5Trace.formalRunMatchingOnly import formalRunBar
import Algorithm.utils as utils

# Traces without knapsack constraint
if __name__ == '__main__':
    K = 1
    barsReward = []
    barsRuntime = []
    barsRewardList = []
    barsRuntimeList = []

    bars = []
    for trace in [1,2,3,100]:
        rewardBar, runtimeBar, rewardConfidentialIntervalList, runtimeConfidentialIntervalList = formalRunBar(trace, K)
        barsReward.append(rewardBar)
        barsRuntime.append(runtimeBar)
        barsRewardList.append(rewardConfidentialIntervalList)
        barsRuntimeList.append(runtimeConfidentialIntervalList)
    print(barsReward, "\n", barsRuntime)
    barsRewardList = utils.calculateConfIntervalForBatch(barsRewardList)
    barsRuntimeList = utils.calculateConfIntervalForBatch(barsRuntimeList)
    print("barsRewardList", barsRewardList)
    print("barsRuntimeList", barsRuntimeList)