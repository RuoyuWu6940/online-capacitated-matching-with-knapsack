import numpy as np
import Algorithm.TraceDriven.traces as traces
import Algorithm.utils as utils


# This file reads trace data and then normalize the edge costs according to K
def prepareTrace(trace, K):
	G, d, c, R, sigma, r = traces.readTrace(trace)
	# clean np.float type
	R = utils.convert_npfloat_to_float(R)
	r = utils.convert_npfloat_to_float(r)
	V = len(G)
	knapsack_factor = (np.sum(np.array(d))/2)/K
	d = (np.array(d)/knapsack_factor).tolist()
	d = utils.truncate_list(d)
	supportReward = len(R[0][0][0])
	pD = [[1 for u in range(V)] for v in range(V)]

	return K, V, G, R, d, pD, sigma, supportReward, c, r,d

