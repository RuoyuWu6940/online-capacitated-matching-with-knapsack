from pulp import LpMaximize, LpProblem, LpStatus, lpSum, LpVariable, value
import Algorithm.ValidateCR.problemInstance as pI
import Algorithm.ValidateCR.samplePath as sP

# This file calculates the offline optimal solution to sample paths sampled by Monte Carlo method

# G: Graph structure G[u,v]=true if there is an edge
# r: realized reward of each edge
# c: the capacity of each node
def LPSolverInt(V, G, r, d, c):
    model = LpProblem(name = "LPRelaxation", sense=LpMaximize)
    X = [[LpVariable(name="x_"+str(u)+","+str(v), cat='Binary') for v in range(V)] for u in range(V)]
    # we only use (u,v) v>u to index edges
    # print(X)
    print("x_{u,v} initialized")
    # capacity constraint
    for u in range(V):
        # each node u has a capacity constraint
        sum_u = 0
        for v in range(V):
            if not G[u,v] or u==v:
                continue
            firstNode = min(u,v)
            secondNode = max(u,v)
            sum_u+=X[firstNode][secondNode]
        model+=(sum_u<=c[u],"stCapa_"+str(u))
    print("capacity constraint initialized")
    # knapsack consraint
    sum_cost=0
    for u in range(V):
        for v in range(u+1,V):
            if not G[u][v] or u==v:
                continue
            firstNode = min(u,v)
            secondNode = max(u,v)
            sum_cost+=d[firstNode][firstNode]*X[firstNode][secondNode]
    model+=(sum_cost<=1,"stKnap")
    # Objective function
    sum = []
    for u in range(V):
        for v in range(u+1,V):
            if not G[u][v]:
                continue
            sum.append(X[u][v]*r[u][v])
    model+=lpSum((sum))
    print("Objective function initialized")
    # Store optimal fractional solution
    X_optimal = [[0 for v in range(V)] for u in range(V)]
    status = model.solve()
    optimal_value = value(model.objective)
    for u in range(V):
        for v in range(u+1,V):
            if G[u][v]:
                X_optimal[u][v]=X_optimal[v][u]=X[u][v].value()
    return(optimal_value)

def OfflineOPT(K,V,G,R,D,pD,sigma,supportReward,c,MonteCarloRounds = 500):
    OPT = 0
    for mcr in range(MonteCarloRounds):
        r,d = sP.samplePath(K,V,G,R,D,pD,sigma,supportReward,c)
        OPT+=LPSolverInt(V, G, r, d, c)
    OPT/=MonteCarloRounds
    return OPT
