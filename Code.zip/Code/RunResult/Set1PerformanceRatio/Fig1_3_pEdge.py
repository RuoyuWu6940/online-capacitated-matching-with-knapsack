import formalRun
if __name__ == '__main__':
    V = 20
    maxCapacity = 7
    minCapacity = 3
    K = 1.5    # Ratio between the expected overall edge cost and the knapsack budget
    supportReward = 3

    bars = []
    for pEdge in [0.2,0.35,0.5,0.65,0.8]:
        bars.append(formalRun.formalRunBar(V,maxCapacity,minCapacity,pEdge,K))
    print(bars)