import math
import random
import time

import numpy
import numpy as np
import bisect

import Algorithm.ValidateCR.problemInstance as pI
import Algorithm.ValidateCR.samplePath as sP
import Algorithm.LPSolver as lp
import Algorithm.utils as utils

# The OCKAOffline function runs the offline preparation phased of OCKA
# One problem instance only needs to run offline once
# The parameters are the problem instance
def OCKAOffline(K,V,G,R,D,pD,sigma,supportReward,c,
                MonteCarloRounds=100):
    X_Optimal_List = []
    for mcr in range(MonteCarloRounds):
        rSample, dSample = sP.samplePath(K,V,G,R,D,pD,sigma,supportReward,c)
        X_Optimal_List.append(lp.LPSolver(V,G,rSample,c))
    Y_Average = [[0 for u in range(V)] for v in range(V)]
    for u in range(V):
        for v in range(u+1,V):
            if not G[u][v]:
                continue
            y_uv = 0
            for sublist in X_Optimal_List:
                y_uv+=sublist[u][v]
            y_uv = y_uv/MonteCarloRounds
            Y_Average[u][v]=Y_Average[v][u]=y_uv
    return(Y_Average)

# This function runs OCKA
def OCKAOnline(K,V,G,R,D,pD,sigma,supportReward,c,r,d,Y_Average):
    # set the pr threshold for cleaning distribution
    prThreshold = 1e-6
    # phase 1 variable
    q_c=np.zeros((V, V), dtype=bool)  #V*V
    arrivedV=[]
    # phase 2 variable
    gamma = 1/(3+math.exp(-2))
    X_Dist_Support = numpy.array([0.00])
    X_Dist_PrMass = numpy.array([1.00])
    X_Consumed = utils.truncate_one_float(1e-5)
    q_k=np.zeros((V, V), dtype=bool)  #V*V
    edgeIteration = 0
    # final decision
    Q=np.zeros((V, V), dtype=bool)    #V*V
    actRemainCapcity = c.copy()
    actRemainKnapsack = 1
    accumulatedReward = 0
    start_time = time.perf_counter()
    for t in range(V):
        print("\nONLINE ROUND:",t)
        v = sigma[t]    # online arrival of time t
        rSample,dSample = sP.samplePath(K,V,G,R,D,pD,sigma,supportReward,c) #dSample will not be used
        B=[]    # revealed edges
        for u in arrivedV:
            if not G[u][v]:
                continue
            rSample[u][v]=rSample[v][u]=r[u][v]
            B.append(u)
        Y_OPT = lp.LPSolver(V,G,rSample,c)
        E_v = []    # edges incident to v, denoted by the node on the other end
        y_uv = []
        for u in range(V):
            if G[u][v] and not u==v:
                E_v.append(u)
                y_uv.append(Y_OPT[u][v])
        # Caratheodory decomposition
        k=0
        lmd = []
        U_v=[]
        while sum(y_uv)>0:
            U_v_k=[E_v[index] for index, value in enumerate(y_uv) if value > 0]
            if len(U_v_k)>c[v]:
                sorted_indices = sorted(enumerate(y_uv), key=lambda x: x[1], reverse=True)
                U_v_k = [E_v[index] for index, value in sorted_indices[:c[v]]]
            U_v.append(U_v_k)
            lmdk = 1
            for e in U_v_k:
                index = E_v.index(e)
                if y_uv[index]<lmdk:
                    lmdk=y_uv[index]
            indicatorU = []
            for e in E_v:
                if e in U_v_k:
                    indicatorU.append(1)
                else:
                    indicatorU.append(0)
            y_uv = (np.array(y_uv)-lmdk*np.array(indicatorU)).tolist()
            lmd.append(lmdk)
        lmd.append(1-sum(lmd))
        U_v.append([])
        #Sample a set U*
        U_star = []
        diceLmd = random.random()
        for k in range(len(lmd)):
            if diceLmd<=lmd[k]:
                U_star=U_v[k]
                break
            diceLmd-=lmd[k]
        # intersection of U* and B
        narrowedU = []
        for u in U_star:
            if u in arrivedV:
                narrowedU.append(u)
        #calculate phi and sample q^c_t
        phi = []
        q_c_t = []
        for u in narrowedU:
            # calculate the remaining capacity
            remainingCapacity = c[u]
            sumPr = 0
            for w in range(V):
                if q_c[u][w] and not u==w:
                    remainingCapacity-=1
                if G[u][w] and w in arrivedV:
                    sumPr+=Y_Average[u][w]
            # calculate phi
            phi_u = (remainingCapacity/c[u])/(2-sumPr/c[u])
            phi.append(phi_u)
            # sample q^c_t
            if phi_u==0:
                continue
            dice_u = random.random()
            if dice_u<=phi_u:
                q_c_t.append(u)
        arrivedV.append(v)
        for u in q_c_t:
            q_c[u][v]=q_c[v][u]=True

        #phase 2 starts; B is the revealed edges (denoted by the node at the another end)
        q_k_t = []
        for u in B:
            edgeIteration += 1
            print("\nEdge Iteration: ", edgeIteration)
            # Find l_1
            theta = max([b_l for b_l in X_Dist_Support if b_l <= 1 - D[u][v]])
            l_1 = np.where(X_Dist_Support == theta)[0][0]
            print("l_1 and theta found:", l_1,theta)
            # Find l_2
            sumPr = 0
            l_2 = l_1 + 1
            while sumPr < gamma:
                l_2 -= 1
                sumPr += X_Dist_PrMass[l_2]
            assert l_2 >= 0
            eta = X_Dist_Support[l_2]
            print("l_2 and eta found:", l_2,eta)
            # Calculate beta
            print("X_Dist_PrMass: ", X_Dist_PrMass)
            print("X_Dist_Support: ", X_Dist_Support)
            beta = (gamma - np.sum(X_Dist_PrMass[l_2 + 1:l_1 + 1])) / (K * X_Dist_PrMass[l_2])
            print("sum[eta,theta]:",sumPr)
            print("sum(eta,theta]:",np.sum(X_Dist_PrMass[l_2 + 1:l_1 + 1]))
            print("gamma:", gamma)
            print("beta calculated:", beta)
            print("Used Knapsack: ", X_Consumed)
            beta = min(1,beta)  # rounding error causes beta>1
            beta = max(0,beta)  #rounding error also causes beta<0
            assert 0 <= beta <= 1
            # Include u with different Pr
            if d[u][v] == 0:
                q_k_t.append(u)
            elif X_Consumed==eta:
                dice = random.random()
                if dice <= beta:
                    q_k_t.append(u)
            elif X_Consumed > eta and X_Consumed <= theta:
                dice = random.random()
                if dice <= 1 / K:
                    q_k_t.append(u)

            print("q^k_t updated for ${v}: ", q_k_t)
            # Update reference knapsack consumption
            if u in q_k_t:
                X_Consumed += d[u][v]
                X_Consumed = utils.truncate_one_float(X_Consumed)
            print("reference knapsack consumption updated")
            # Update reference consumption distribution
            X_Dist_Support_New = X_Dist_Support.copy()
            X_Dist_PrMass_New = X_Dist_PrMass.copy()
            for l in range(l_2 + 1, l_1 + 1):  # (eta, theta]
                b = X_Dist_Support[l]
                movedPr = (pD[u][v] / K) * X_Dist_PrMass[l]
                idx = np.where(X_Dist_Support_New == b)[0][0]
                X_Dist_PrMass_New[idx] -= movedPr
                moved_to = b + D[u][v]
                moved_to = utils.truncate_one_float(moved_to)
                if moved_to in X_Dist_Support_New:
                    idx_to = np.where(X_Dist_Support_New == moved_to)[0][0]
                    X_Dist_PrMass_New[idx_to] += movedPr
                else:
                    idx_insert = bisect.bisect(X_Dist_Support_New, moved_to)
                    X_Dist_Support_New = np.insert(X_Dist_Support_New, idx_insert, moved_to)
                    X_Dist_PrMass_New = np.insert(X_Dist_PrMass_New, idx_insert, movedPr)
            # At eta
            movedPr = pD[u][v] * beta * X_Dist_PrMass[l_2]
            idx_eta = np.where(X_Dist_Support_New == eta)[0][0]
            X_Dist_PrMass_New[idx_eta] = X_Dist_PrMass_New[idx_eta] - movedPr
            moved_to = eta + D[u][v]
            moved_to = utils.truncate_one_float(moved_to)
            if moved_to in X_Dist_Support_New:
                idx_to = np.where(X_Dist_Support_New == moved_to)[0][0]
                X_Dist_PrMass_New[idx_to] += movedPr
            else:
                idx_insert = bisect.bisect(X_Dist_Support_New, moved_to)
                X_Dist_Support_New = np.insert(X_Dist_Support_New, idx_insert, moved_to)
                X_Dist_PrMass_New = np.insert(X_Dist_PrMass_New, idx_insert, movedPr)
            X_Dist_Support = X_Dist_Support_New
            X_Dist_PrMass = X_Dist_PrMass_New
            # clean the support with less than prThreshold pr mass
            mask = X_Dist_PrMass >= prThreshold
            X_Dist_Support = X_Dist_Support[mask]
            X_Dist_PrMass = X_Dist_PrMass[mask]
            X_Dist_PrMass /= X_Dist_PrMass.sum()
            print("reference consumption distribution updated, new length:", len(X_Dist_Support))
        # knapsack part done
        for u in q_k_t:
            q_k[u][v]=q_k[v][u]=True
        # final decision and update remaining capacity and knapsack
        for u in q_c_t:
            if u in q_k_t:
                Q[u,v]=Q[v][u]=True
                actRemainCapcity[u]-=1
                assert actRemainCapcity[u]>=0
                actRemainCapcity[v]-=1
                assert actRemainCapcity[v]>=0
                actRemainKnapsack-=d[u][v]
                assert actRemainKnapsack>=0
                accumulatedReward+=r[u][v]
        #done
    end_time = time.perf_counter()
    runtime = (end_time-start_time)/V
    print(accumulatedReward, runtime)
    return accumulatedReward, runtime
