import formalRun
if __name__ == '__main__':
    maxCapacity = 7
    minCapacity = 3
    pEdge=0.5  # Pr{an edge is set}
    K = 1.5    # Ratio between the expected overall edge cost and the knapsack budget
    supportReward = 3

    bars = []
    for V in [10,15,20,25,30]:
        bars.append(formalRun.formalRunBar(V,maxCapacity,minCapacity,pEdge,K))
    print(bars)