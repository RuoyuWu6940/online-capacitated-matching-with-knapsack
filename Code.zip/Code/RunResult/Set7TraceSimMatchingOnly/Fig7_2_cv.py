from RunResult.Set7TraceSimMatchingOnly.formalRun import formalRunBar
import Algorithm.SimulationTraceDriven.problemInstance as pI
import Algorithm.utils as utils


#
if __name__ == '__main__':
    trace = 1
    K = 1
    V = 100
    barsReward = []
    barsRuntime = []
    barsRewardList = []
    barsRuntimeList = []

    for midC in [3, 4, 5, 6, 7]:  # midC = [3, 4, 5, 6, 7]
        maxCapacity = midC + 2
        minCapacity = midC - 2
        K, V, G, R, D, pD, sigma, supportReward, c = pI.problemInstanceCv(K, V, maxCapacity, minCapacity)
        rewardBar, runtimeBar,rewardConfidentialIntervalList,runtimeConfidentialIntervalList = formalRunBar(K, V, G, R, D, pD, sigma, supportReward, c)
        barsReward.append(rewardBar)
        barsRuntime.append(runtimeBar)
        barsRewardList.append(rewardConfidentialIntervalList)
        barsRuntimeList.append(runtimeConfidentialIntervalList)
    print(barsReward, "\n", barsRuntime)
    barsRewardList = utils.calculateConfIntervalForBatch(barsRewardList)
    barsRuntimeList = utils.calculateConfIntervalForBatch(barsRuntimeList)
    print("barsRewardList", barsRewardList)
    print("barsRuntimeList", barsRuntimeList)