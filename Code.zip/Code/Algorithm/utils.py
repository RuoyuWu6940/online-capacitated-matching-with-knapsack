import math
from typing import Any
import numpy as np
from scipy import stats

# This file includes util functions used in this project.

# This function truncates float numbers
def truncate_one_float(num):
	scale = 10 ** 5
	return math.trunc(num * scale) / scale

# This function truncates every float in a list / tuple or mixed data structure
def truncate_list(data: Any):

    if isinstance(data, float):
        return truncate_one_float(data)

    if isinstance(data, list):
        return [truncate_list(item) for item in data]

    if isinstance(data, tuple):
        return tuple(truncate_list(item) for item in data)

    return data

# This function converts np.float data type to float
def convert_npfloat_to_float(obj):
    if isinstance(obj, list):
        return [convert_npfloat_to_float(x) for x in obj]
    elif isinstance(obj, np.floating):
        return float(obj)
    else:
        return obj

# rounding
def round_half_up_to_int(x: float) -> int:
    if not (0.0 <= x <= 1.0):
        raise ValueError("x must be in [0, 1]")
    return int(x + 0.5)

# calculate the confidence interval (half-interval distance) for a list of numbers
def ConfidenceInterval(data):
    n = len(data)
    # for Greedy, the performance should be deterministic
    if n==1:
        return 0
    confidence = 0.95
    alpha = 1-confidence
    percentile = 1-alpha/2
    mean = np.mean(data)
    std = np.std(data, ddof=1)  # sample standard deviation (s)
    tcrit = stats.t.ppf(percentile, df=n - 1)
    half = tcrit * std / np.sqrt(n)
    return convert_npfloat_to_float(half)

# calculate the confidence interval (half-interval distance) for a list of lists of numbers
def calculateConfIntervalForBatch(points):
    confInt = [[] for _ in range(len(points))]
    for i in range(len(points)):
        for j in range(len(points[i])):
            confInt[i].append(ConfidenceInterval(points[i][j]))
    return confInt

