
csv_path_prefix = "/Algorithm/TraceDriven"

# This file reads the trace data from csv

def readTraceFromTwoCSV(edge_csv_path, node_csv_path):
    import pandas as pd
    import numpy as np

    rewardlist = [0.05, 0.15, 0.25, 0.35, 0.45, 0.55, 0.65, 0.75, 0.85, 0.95]
    bin_cols = [f"bin_{b:.2f}" for b in rewardlist]

    edge_df = pd.read_csv(edge_csv_path)
    node_df = pd.read_csv(node_csv_path)

    # All unique uids
    all_uids = sorted(set(edge_df['dater_uid']).union(edge_df['dated_uid']).union(set(node_df['uid'])))
    uid_index = {uid: i for i, uid in enumerate(all_uids)}
    V = len(all_uids)

    # Init
    G = np.full((V, V), False)
    D = np.full((V, V), 0.0)
    r = np.full((V, V), 0.0)
    R = [[[rewardlist[:], [0.0]*len(rewardlist)] for _ in range(V)] for _ in range(V)]
    c = [0] * V
    sigma = [0] * V

    for _, row in edge_df.iterrows():
        u = uid_index[row['dater_uid']]
        v = uid_index[row['dated_uid']]
        G[u][v] = G[v][u] = True
        D[u][v] = D[v][u] = row['final_moral_cost']
        r[u][v] = r[v][u] = row['real_reward']
        prob_list = [row[col] for col in bin_cols]
        R[u][v] = R[v][u] = [rewardlist[:], prob_list]

    for _, row in node_df.iterrows():
        i = uid_index[row['uid']]
        c[i] = int(row['capacity_c'])
        sigma[int(row['sigma_order'])] = i

    return G, D.tolist(), c, R, sigma, r.tolist()


def readTrace(i):
    return readTraceFromTwoCSV(csv_path_prefix+f"/edges_trace{i}_good.csv",
                               csv_path_prefix+f"/nodes_trace{i}_good.csv")

