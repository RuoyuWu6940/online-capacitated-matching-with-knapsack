import numpy as np
import random

# This file is the same as Numerical/samplePath

def samplePath(K,V,G,R,D,pD,sigma,supportReward,c):
    # Sample Path
    r = [[0 for u in range(V)] for v in range(V)] # sampled edge reward
    d = [[0 for u in range(V)] for v in range(V)] # sampled edge cost
    for u in range(V):
        for v in range(u+1,V):
            if G[u,v]:
                diceR = random.random()
                for p in range(supportReward):
                    if diceR<=R[u][v][1][p]:
                        r[u][v]=r[v][u]=R[u][v][0][p]
                        break
                    diceR=diceR-R[u][v][1][p]
                diceD = random.random()
                if diceD<pD[u][v]:
                    d[u][v]=d[v][u]=D[u][v]
    # Sample Path Generated
    return r,d
