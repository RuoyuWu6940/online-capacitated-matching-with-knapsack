import math
import random
import time

import numpy
import numpy as np

import Algorithm.ValidateCR.samplePath as sP
import Algorithm.LPSolver as lp

# The OCKAOffline function runs the Offline  Preparation phase when the knapsack constraint is not imposed
# One problem instance only needs to run offline once
# The parameters are the problem instance
def OCKAOffline(K,V,G,R,D,pD,sigma,supportReward,c,
                MonteCarloRounds=100):
    X_Optimal_List = []
    for mcr in range(MonteCarloRounds):
        rSample, dSample = sP.samplePath(K,V,G,R,D,pD,sigma,supportReward,c)
        X_Optimal_List.append(lp.LPSolver(V,G,rSample,c))
    Y_Average = [[0 for u in range(V)] for v in range(V)]
    for u in range(V):
        for v in range(u+1,V):
            if not G[u][v]:
                continue
            y_uv = 0
            for sublist in X_Optimal_List:
                y_uv+=sublist[u][v]
            y_uv = y_uv/MonteCarloRounds
            Y_Average[u][v]=Y_Average[v][u]=y_uv
    return(Y_Average)

# This function runs the OCKA when the knapsack constraint is noty imposed
def OCKAOnline(K,V,G,R,D,pD,sigma,supportReward,c,r,d,Y_Average):
    # phase 1 variable
    q_c=np.zeros((V, V), dtype=bool)  #V*V
    arrivedV=[]
    # phase 2 variable
    gamma = 1/(3+math.exp(-2))
    X_Dist_Support = numpy.array([0.00])
    X_Dist_PrMass = numpy.array([1.00])
    X_Consumed = 0
    q_k=np.zeros((V, V), dtype=bool)  #V*V
    # final decision
    Q=np.zeros((V, V), dtype=bool)    #V*V
    actRemainCapcity = c.copy()
    actRemainKnapsack = 1
    accumulatedReward = 0
    start_time = time.perf_counter()
    for t in range(V):
        print("ONLINE ROUND:",t)
        v = sigma[t]    # online arrival of time t
        rSample,dSample = sP.samplePath(K,V,G,R,D,pD,sigma,supportReward,c) #dSample will not be used
        B=[]    # revealed edges
        for u in arrivedV:
            if not G[u][v]:
                continue
            rSample[u][v]=rSample[v][u]=r[u][v]
            B.append(u)
        Y_OPT = lp.LPSolver(V,G,rSample,c)
        E_v = []    # edges incident to v, denoted by the node on the other end
        y_uv = []
        for u in range(V):
            if G[u][v] and not u==v:
                E_v.append(u)
                y_uv.append(Y_OPT[u][v])
        # Caratheodory decomposition
        k=0
        lmd = []
        U_v=[]
        while sum(y_uv)>0:
            U_v_k=[E_v[index] for index, value in enumerate(y_uv) if value > 0]
            if len(U_v_k)>c[v]:
                sorted_indices = sorted(enumerate(y_uv), key=lambda x: x[1], reverse=True)
                U_v_k = [E_v[index] for index, value in sorted_indices[:c[v]]]
            U_v.append(U_v_k)
            lmdk = 1
            for e in U_v_k:
                index = E_v.index(e)
                if y_uv[index]<lmdk:
                    lmdk=y_uv[index]
            indicatorU = []
            for e in E_v:
                if e in U_v_k:
                    indicatorU.append(1)
                else:
                    indicatorU.append(0)
            y_uv = (np.array(y_uv)-lmdk*np.array(indicatorU)).tolist()
            lmd.append(lmdk)
        lmd.append(1-sum(lmd))
        U_v.append([])
        #Sample a set U*
        U_star = []
        diceLmd = random.random()
        for k in range(len(lmd)):
            if diceLmd<=lmd[k]:
                U_star=U_v[k]
                break
            diceLmd-=lmd[k]
        # intersection of U* and B
        narrowedU = []
        for u in U_star:
            if u in arrivedV:
                narrowedU.append(u)
        #calculate phi and sample q^c_t
        phi = []
        q_c_t = []
        for u in narrowedU:
            # calculate the remaining capacity
            remainingCapacity = c[u]
            sumPr = 0
            for w in range(V):
                if q_c[u][w] and not u==w:
                    remainingCapacity-=1
                if G[u][w] and w in arrivedV:
                    sumPr+=Y_Average[u][w]
            # calculate phi
            phi_u = (remainingCapacity/c[u])/(2-sumPr/c[u])
            phi.append(phi_u)
            # sample q^c_t
            if phi_u==0:
                continue
            dice_u = random.random()
            if dice_u<=phi_u:
                q_c_t.append(u)
        arrivedV.append(v)
        for u in q_c_t:
            q_c[u][v]=q_c[v][u]=True
        # phase 1 completed

        # final decision and update remaining capacity and knapsack
        for u in q_c_t:
            Q[u,v]=Q[v][u]=True
            actRemainCapcity[u]-=1
            assert actRemainCapcity[u]>=0
            actRemainCapcity[v]-=1
            assert actRemainCapcity[v]>=0
            accumulatedReward+=r[u][v]
        #done
    end_time = time.perf_counter()
    runtime = (end_time-start_time)/V
    print(accumulatedReward, runtime)
    return accumulatedReward, runtime

