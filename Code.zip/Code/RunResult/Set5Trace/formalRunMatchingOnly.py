import math

from Algorithm.matchingOnlyOCKA import OCKAOffline, OCKAOnline
import Algorithm.Benchmarks as bmk
from Algorithm.TraceDriven.prepareTrace import prepareTrace
import Algorithm.utils as utils


def formalRunBar(trace,K):

    K=1
    algRuns = 10
    gamma = 1/(3+math.exp(-2))


    K, V, G, R, D, pD, sigma, supportReward, c, r,d = prepareTrace(trace,K)

    Y_AVG = OCKAOffline(K, V, G, R, D, pD, sigma, supportReward, c, MonteCarloRounds=500)

    E_OCKA = 0
    E_Random = 0
    E_Greedy = 0
    E_Adaptive = 0
    E_Matching = 0
    E_Secretary = 0
    E_SecretaryComplete = 0

    E_OCKA_Runtime = 0
    E_Random_Runtime = 0
    E_Greedy_Runtime = 0
    E_Adaptive_Runtime = 0
    E_Matching_Runtime = 0
    E_Secretary_Runtime = 0
    E_SecretaryComplete_Runtime = 0

    E_OCKA_List = []
    E_Random_List = []
    E_Greedy_List = []
    E_Adaptive_List = []
    E_Matching_List = []
    E_Secretary_List = []
    E_SecretaryComplete_List = []

    E_OCKA_Runtime_List = []
    E_Random_Runtime_List = []
    E_Greedy_Runtime_List = []
    E_Adaptive_Runtime_List = []
    E_Matching_Runtime_List = []
    E_Secretary_Runtime_List = []
    E_SecretaryComplete_Runtime_List = []
    for paths in range(algRuns):
        OCKA_accumulatedReward, OCKA_runtime = OCKAOnline(K,V,G,R,D,pD,sigma,supportReward,c,r,d,Y_AVG)
        Random_accumulatedReward, Random_runtime = bmk.Random(K,V,G,R,D,pD,sigma,supportReward,c,r,d)
        Adaptive_accumulatedReward, Adaptive_runtime = bmk.Adaptive(K,V,G,R,D,pD,sigma,supportReward,c,r,d)
        Matching_accumulatedReward, Matching_runtime = bmk.SingleOCKATrace(K,V,G,R,D,pD,sigma,supportReward,c,r,d,Y_AVG)
        Secretary_accumulatedReward, Secretary_runtime = bmk.SecretaryGeneralMatching(K,V,G,R,D,pD,sigma,supportReward,c,r,d,Y_AVG)
        SecretaryComplete_accumulatedReward, SecretaryComplete_runtime = bmk.SecretaryCompleteMatching(K,V,G,R,D,pD,sigma,supportReward,c,r,d,Y_AVG)

        E_OCKA+=OCKA_accumulatedReward
        E_Random+=Random_accumulatedReward
        E_Adaptive+=Adaptive_accumulatedReward
        E_Matching+=Matching_accumulatedReward
        E_Secretary += Secretary_accumulatedReward
        E_SecretaryComplete += SecretaryComplete_accumulatedReward

        E_OCKA_Runtime += OCKA_runtime
        E_Random_Runtime += Random_runtime
        E_Adaptive_Runtime += Adaptive_runtime
        E_Matching_Runtime += Matching_runtime
        E_Secretary_Runtime += Secretary_runtime
        E_SecretaryComplete_Runtime += SecretaryComplete_runtime

        E_OCKA_List.append(OCKA_accumulatedReward)
        E_Random_List.append(Random_accumulatedReward)
        E_Adaptive_List.append(Adaptive_accumulatedReward)
        E_Matching_List.append(Matching_accumulatedReward)
        E_Secretary_List.append(Secretary_accumulatedReward)
        E_SecretaryComplete_List.append(SecretaryComplete_accumulatedReward)

        E_OCKA_Runtime_List.append(OCKA_runtime)
        E_Random_Runtime_List.append(Random_runtime)
        E_Adaptive_Runtime_List.append(Adaptive_runtime)
        E_Matching_Runtime_List.append(Matching_runtime)
        E_Secretary_Runtime_List.append(Secretary_runtime)
        E_SecretaryComplete_Runtime_List.append(SecretaryComplete_runtime)

    Greedy_accumulatedReward, Greedy_runtime = bmk.Greedy(K, V, G, R, D, pD, sigma, supportReward, c, r, d)
    E_Greedy += Greedy_accumulatedReward
    E_Greedy_Runtime += Greedy_runtime
    E_Greedy_List.append(Greedy_accumulatedReward)
    E_Greedy_Runtime_List.append(Greedy_runtime)

    E_OCKA/=algRuns
    E_Random/=algRuns
    E_Adaptive/=algRuns
    E_Matching/=algRuns
    E_Secretary/=algRuns
    E_SecretaryComplete/=algRuns

    E_OCKA_Runtime /= algRuns
    E_Random_Runtime /= algRuns
    E_Adaptive_Runtime /= algRuns
    E_Matching_Runtime /= algRuns
    E_Secretary_Runtime /= algRuns
    E_SecretaryComplete_Runtime /= algRuns

    avgList = [E_OCKA,E_Random,E_Greedy,E_Adaptive,E_Matching,E_Secretary, E_SecretaryComplete]
    runTimeList = [E_OCKA_Runtime, E_Random_Runtime, E_Greedy_Runtime, E_Adaptive_Runtime,
                   E_Matching_Runtime, E_Secretary_Runtime, E_SecretaryComplete_Runtime]

    avgConfidentialIntervalList = [E_OCKA_List, E_Random_List, E_Greedy_List, E_Adaptive_List,
                                   E_Matching_List, E_Secretary_List, E_SecretaryComplete_List]
    runtimeConfidentialIntervalList = [E_OCKA_Runtime_List, E_Random_Runtime_List, E_Greedy_Runtime_List,
                                       E_Adaptive_Runtime_List, E_Matching_Runtime_List,
                                       E_Secretary_Runtime_List, E_SecretaryComplete_Runtime_List]

    # calculate conf interval
    avgConfidentialIntervalList = [E_OCKA_List,E_Random_List,E_Greedy_List,E_Adaptive_List,
                                   E_Matching_List,E_Secretary_List,E_SecretaryComplete_List]
    runtimeConfidentialIntervalList = [E_OCKA_Runtime_List,E_Random_Runtime_List,E_Greedy_Runtime_List,
                                       E_Adaptive_Runtime_List,E_Matching_Runtime_List,
                                       E_Secretary_Runtime_List,E_SecretaryComplete_Runtime_List]



    return avgList, runTimeList, avgConfidentialIntervalList,runtimeConfidentialIntervalList
